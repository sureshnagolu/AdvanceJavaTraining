
import java.util.Iterator;
import java.util.Scanner;

public class PhoneBook {

	public static String help_msg= "Press: 1 Add contact 2 Search 3 Exit :";
	public static void main(String[] args) {
		
		System.out.println("\n\n*** My phone book ***\n\n");
		Scanner s=new Scanner(System.in);
		for (;;) {
			System.out.print("[Main Menu] "+help_msg+"\n:");
			String command=s.nextLine().trim();
			
			if (command.equalsIgnoreCase("A")) {
				System.out.println("Searching for contact details: name, lastname, phone\n: ");
				
			}
			else if (command.equalsIgnoreCase("S")) {
				System.out.println(" searching for the name :\n:");
				
			}
			else if (command.equalsIgnoreCase("Q")) {
				System.out.println(" Bye User...");
				System.exit(0);
			}
			else {
				System.out.println("Unknown command ! Try Again \n:");
			}
		}
	}
}


public class SplitMethod {
public static void main(String[] args) {
			
		String txt= (" 1432  +  143  -  (  246  /  6  ) ");
		String[] w=txt.split("\\\s");
		
		for(String w1:w){  
			System.out.println(w1); 
			
		}
	}

	}


public class RectangleTest {
	private int length = 1;
	private int width = 1;
	
	void calculate() {
    int    area = length * width;
       int  perimeter = 2 * (length + width);
       System.out.println("Area of rectangle is::"+area +"and Perimeter is::"+perimeter);
    }

	public static void main(String[] args) {
		
		RectangleTest test =new RectangleTest();
		test.calculate();
	}
	public int getLength() {
		
		return length;
	}

	public void setLength(int length) {
		if(length>0.0&&length <20.0) {
		this.length = length;
		}
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		if(width>0.0&& width<20.0) {
		this.width = width;
		}
	}


}
